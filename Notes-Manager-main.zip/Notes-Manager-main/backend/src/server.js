
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const pool = require('./db');

const app = express();
const port = Number(process.env.PORT || 5000);
const allowedOrigin = process.env.FRONTEND_ORIGIN || 'http://localhost:5173';

app.use(cors({
  origin: allowedOrigin.split(',').map(v => v.trim())
}));

app.use(express.json({ limit: '100kb' }));

// Reusable note fields
const NOTE_FIELDS = `
  id,
  title,
  content,
  is_pinned AS isPinned,
  created_at AS createdAt,
  updated_at AS updatedAt
`;

// Validate IDs received from the frontend
function normalizeIds(value) {
  if (!Array.isArray(value)) return [];

  const ids = value.map(Number);

  if (
    ids.some(id => !Number.isSafeInteger(id) || id < 1)
  ) {
    return null;
  }

  return [...new Set(ids)];
}

// Add categories and tags to a list of notes
async function attachRelations(notes) {
  if (!notes.length) return notes;

  const noteIds = notes.map(note => note.id);
  const placeholders = noteIds.map(() => '?').join(',');

  const [categoryRows] = await pool.execute(
    `SELECT nc.note_id AS noteId, c.id, c.name
     FROM note_categories nc
     JOIN categories c ON c.id = nc.category_id
     WHERE nc.note_id IN (${placeholders})
     ORDER BY c.name`,
    noteIds
  );

  const [tagRows] = await pool.execute(
    `SELECT nt.note_id AS noteId, t.id, t.name
     FROM note_tags nt
     JOIN tags t ON t.id = nt.tag_id
     WHERE nt.note_id IN (${placeholders})
     ORDER BY t.name`,
    noteIds
  );

  const categoryMap = new Map();
  const tagMap = new Map();

  for (const row of categoryRows) {
    if (!categoryMap.has(row.noteId)) {
      categoryMap.set(row.noteId, []);
    }

    categoryMap.get(row.noteId).push({
      id: row.id,
      name: row.name
    });
  }

  for (const row of tagRows) {
    if (!tagMap.has(row.noteId)) {
      tagMap.set(row.noteId, []);
    }

    tagMap.get(row.noteId).push({
      id: row.id,
      name: row.name
    });
  }

  return notes.map(note => ({
    ...note,
    categories: categoryMap.get(note.id) || [],
    tags: tagMap.get(note.id) || []
  }));
}

// Get one note with its categories and tags
async function getNote(id) {
  const [rows] = await pool.execute(
    `SELECT ${NOTE_FIELDS} FROM notes WHERE id = ?`,
    [id]
  );

  if (!rows.length) return null;

  const result = await attachRelations(rows);
  return result[0];
}

// Save category and tag relationships using a transaction connection
async function saveRelations(connection, noteId, categoryIds, tagIds) {
  if (categoryIds !== undefined) {
    await connection.execute(
      'DELETE FROM note_categories WHERE note_id = ?',
      [noteId]
    );

    for (const categoryId of categoryIds) {
      await connection.execute(
        'INSERT INTO note_categories (note_id, category_id) VALUES (?, ?)',
        [noteId, categoryId]
      );
    }
  }

  if (tagIds !== undefined) {
    await connection.execute(
      'DELETE FROM note_tags WHERE note_id = ?',
      [noteId]
    );

    for (const tagId of tagIds) {
      await connection.execute(
        'INSERT INTO note_tags (note_id, tag_id) VALUES (?, ?)',
        [noteId, tagId]
      );
    }
  }
}

// Health check
app.get('/api/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');

    res.json({
      status: 'ok',
      service: 'notes-manager-api',
      database: 'connected'
    });
  } catch (error) {
    console.error('Health check database error:', error.message);
    res.status(503).json({
      status: 'error',
      database: 'unavailable'
    });
  }
});

// Get all categories
app.get('/api/categories', async (_req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, name FROM categories ORDER BY name'
    );

    res.json(rows);
  } catch (error) {
    console.error('List categories error:', error.message);
    res.status(500).json({ error: 'Could not load categories.' });
  }
});

// Create a category
app.post('/api/categories', async (req, res) => {
  const name = String(req.body.name || '').trim();

  if (!name) {
    return res.status(400).json({ error: 'Category name is required.' });
  }

  if (name.length > 80) {
    return res.status(400).json({ error: 'Category name must be 80 characters or fewer.' });
  }

  try {
    const [result] = await pool.execute(
      'INSERT INTO categories (name) VALUES (?)',
      [name]
    );

    res.status(201).json({
      id: result.insertId,
      name
    });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'That category already exists.' });
    }

    console.error('Create category error:', error.message);
    res.status(500).json({ error: 'Could not create category.' });
  }
});

// Get all tags
app.get('/api/tags', async (_req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, name FROM tags ORDER BY name'
    );

    res.json(rows);
  } catch (error) {
    console.error('List tags error:', error.message);
    res.status(500).json({ error: 'Could not load tags.' });
  }
});

// Create a tag
app.post('/api/tags', async (req, res) => {
  const name = String(req.body.name || '').trim();

  if (!name) {
    return res.status(400).json({ error: 'Tag name is required.' });
  }

  if (name.length > 80) {
    return res.status(400).json({ error: 'Tag name must be 80 characters or fewer.' });
  }

  try {
    const [result] = await pool.execute(
      'INSERT INTO tags (name) VALUES (?)',
      [name]
    );

    res.status(201).json({
      id: result.insertId,
      name
    });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'That tag already exists.' });
    }

    console.error('Create tag error:', error.message);
    res.status(500).json({ error: 'Could not create tag.' });
  }
});

// Get notes, including their categories and tags
app.get('/api/notes', async (req, res) => {
  try {
    const search = String(req.query.search || '').trim();

    let sql = `SELECT ${NOTE_FIELDS} FROM notes`;
    const params = [];

    if (search) {
      sql += ' WHERE title LIKE ? OR content LIKE ?';
      params.push(`%${search}%`, `%${search}%`);
    }

    sql += ' ORDER BY is_pinned DESC, updated_at DESC';

    const [rows] = await pool.execute(sql, params);
    const notes = await attachRelations(rows);

    res.json(notes);
  } catch (error) {
    console.error('List notes error:', error.message);
    res.status(500).json({ error: 'Could not load notes.' });
  }
});

// Create a note
app.post('/api/notes', async (req, res) => {
  const title = String(req.body.title || '').trim();
  const content = String(req.body.content || '').trim();

  const categoryIds = req.body.categoryIds === undefined
    ? []
    : normalizeIds(req.body.categoryIds);

  const tagIds = req.body.tagIds === undefined
    ? []
    : normalizeIds(req.body.tagIds);

  if (!title || !content) {
    return res.status(400).json({
      error: 'Title and content are required.'
    });
  }

  if (title.length > 160) {
    return res.status(400).json({
      error: 'Title must be 160 characters or fewer.'
    });
  }

  if (categoryIds === null || tagIds === null) {
    return res.status(400).json({
      error: 'Invalid category or tag IDs.'
    });
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [result] = await connection.execute(
      'INSERT INTO notes (title, content) VALUES (?, ?)',
      [title, content]
    );

    await saveRelations(
      connection,
      result.insertId,
      categoryIds,
      tagIds
    );

    await connection.commit();

    const note = await getNote(result.insertId);
    res.status(201).json(note);
  } catch (error) {
    await connection.rollback();

    console.error('Create note error:', error.message);

    if (error.code === 'ER_NO_REFERENCED_ROW_2') {
      return res.status(400).json({
        error: 'One of the selected categories or tags does not exist.'
      });
    }

    res.status(500).json({ error: 'Could not create note.' });
  } finally {
    connection.release();
  }
});

// Update a note
app.put('/api/notes/:id', async (req, res) => {
  const id = Number(req.params.id);
  const title = String(req.body.title || '').trim();
  const content = String(req.body.content || '').trim();

  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(400).json({ error: 'Invalid note ID.' });
  }

  if (!title || !content) {
    return res.status(400).json({
      error: 'Title and content are required.'
    });
  }

  if (title.length > 160) {
    return res.status(400).json({
      error: 'Title must be 160 characters or fewer.'
    });
  }

  const categoryIds = req.body.categoryIds === undefined
    ? undefined
    : normalizeIds(req.body.categoryIds);

  const tagIds = req.body.tagIds === undefined
    ? undefined
    : normalizeIds(req.body.tagIds);

  if (categoryIds === null || tagIds === null) {
    return res.status(400).json({
      error: 'Invalid category or tag IDs.'
    });
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [result] = await connection.execute(
      'UPDATE notes SET title = ?, content = ? WHERE id = ?',
      [title, content, id]
    );

    if (!result.affectedRows) {
      await connection.rollback();
      return res.status(404).json({ error: 'Note not found.' });
    }

    await saveRelations(
      connection,
      id,
      categoryIds,
      tagIds
    );

    await connection.commit();

    const note = await getNote(id);
    res.json(note);
  } catch (error) {
    await connection.rollback();

    console.error('Update note error:', error.message);

    if (error.code === 'ER_NO_REFERENCED_ROW_2') {
      return res.status(400).json({
        error: 'One of the selected categories or tags does not exist.'
      });
    }

    res.status(500).json({ error: 'Could not update note.' });
  } finally {
    connection.release();
  }
});

// Pin or unpin a note
app.patch('/api/notes/:id/pin', async (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(400).json({ error: 'Invalid note ID.' });
  }

  try {
    const [result] = await pool.execute(
      'UPDATE notes SET is_pinned = NOT is_pinned WHERE id = ?',
      [id]
    );

    if (!result.affectedRows) {
      return res.status(404).json({ error: 'Note not found.' });
    }

    const note = await getNote(id);
    res.json(note);
  } catch (error) {
    console.error('Pin note error:', error.message);
    res.status(500).json({ error: 'Could not change pin status.' });
  }
});

// Delete a note
app.delete('/api/notes/:id', async (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(400).json({ error: 'Invalid note ID.' });
  }

  try {
    const [result] = await pool.execute(
      'DELETE FROM notes WHERE id = ?',
      [id]
    );

    if (!result.affectedRows) {
      return res.status(404).json({ error: 'Note not found.' });
    }

    res.status(204).end();
  } catch (error) {
    console.error('Delete note error:', error.message);
    res.status(500).json({ error: 'Could not delete note.' });
  }
});

// Handle unexpected errors
app.use((err, _req, res, _next) => {
  console.error('Unexpected error:', err.message);
  res.status(500).json({ error: 'Unexpected server error.' });
});

// Start server
app.listen(port, () => {
  console.log(`Notes Manager API listening on port ${port}`);
});
