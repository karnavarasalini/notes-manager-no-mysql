# Notes Manager — AWS Deployment Project

A beginner-friendly full-stack Notes Manager using React, Express, and MySQL.

## Features
- Create, view, edit, and delete notes
- Search notes by title or content
- Pin and unpin important notes
- Responsive dashboard
- MySQL persistent storage
- REST API with basic input validation
- Ready-to-configure for AWS EC2 + RDS + S3/CloudFront

## Technology stack
- Frontend: React + Vite + CSS
- Backend: Node.js + Express
- Database: MySQL 8
- MySQL driver: mysql2
- Cloud deployment: EC2 (API), RDS for MySQL (database), S3/CloudFront (frontend)

## Project structure
```
notes-manager-aws/
├── backend/
│   ├── src/
│   │   ├── db.js
│   │   └── server.js
│   ├── sql/schema.sql
│   ├── .env.example
│   ├── package.json
│   └── .gitignore
├── frontend/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── index.html
│   ├── .env.example
│   ├── package.json
│   └── .gitignore
└── .gitignore
```

## 1. Run locally (Windows / VS Code)

Install Node.js LTS and MySQL 8. Open this project folder in VS Code.

### Create the database
Open MySQL Workbench or the MySQL command line and run:
```sql
CREATE DATABASE notes_manager;
```
Then run the SQL in `backend/sql/schema.sql`.

### Start the backend
Open a terminal:
```powershell
cd backend
npm install
Copy-Item .env.example .env
```
Edit `backend/.env` with your local MySQL username and password. Then:
```powershell
npm run dev
```
Backend runs at `http://localhost:5000`. Test `http://localhost:5000/api/health`.

### Start the frontend
Open a second terminal:
```powershell
cd frontend
npm install
Copy-Item .env.example .env
npm run dev
```
Open the Vite URL shown in the terminal (normally `http://localhost:5173`).

## 2. Push to GitHub
From the project root:
```powershell
git init
git add .
git commit -m "Initial Notes Manager project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
Create an empty GitHub repository first. Do not upload `.env` files or passwords.

## 3. AWS deployment overview

This project is designed for:
- **Amazon EC2**: runs the Express API.
- **Amazon RDS for MySQL**: stores notes persistently.
- **Amazon S3**: stores the built frontend files.
- **Amazon CloudFront (optional)**: serves the frontend over HTTPS.

AWS Free Tier eligibility, credits, regional availability, and charges depend on your account and current AWS offer. Do not assume these services will remain free. Set an AWS Budget alert and review the pricing estimate before creating resources.

### A. Create the MySQL database in RDS
1. In AWS Console, open RDS → Databases → Create database.
2. Choose MySQL and a configuration eligible for your account's current offer.
3. For a learning project, choose a small instance and avoid Multi-AZ.
4. Set a strong database password and save it securely.
5. Set **Public access: No**.
6. Create a security group rule allowing MySQL port `3306` only from the EC2 security group.
7. After creation, copy the RDS endpoint.

Do not open port 3306 to `0.0.0.0/0`.

### B. Create the database tables
Connect to the RDS database from a permitted client (for example, a temporary EC2 connection or a securely configured MySQL client). Run:
`backend/sql/schema.sql`

### C. Deploy the backend to EC2
1. Create an EC2 instance using an OS and instance type eligible for your account's current offer.
2. Configure its security group:
   - SSH `22`: only your own IP address.
   - HTTP `80`: public, if using a reverse proxy.
   - Do not expose MySQL `3306`.
3. Connect to EC2 and install Node.js LTS and Git using the official instructions for your chosen Linux distribution.
4. Clone your GitHub repository.
5. In the `backend` folder run `npm install --omit=dev`.
6. Create `backend/.env` on the server (never commit it):
```
PORT=5000
DB_HOST=YOUR_RDS_ENDPOINT
DB_PORT=3306
DB_USER=YOUR_DB_USERNAME
DB_PASSWORD=YOUR_DB_PASSWORD
DB_NAME=notes_manager
FRONTEND_ORIGIN=https://YOUR_FRONTEND_DOMAIN
```
7. Start the API with a process manager such as PM2, or configure a systemd service. For a first test, `npm start` is sufficient while the SSH session remains open.
8. Test `http://YOUR_EC2_PUBLIC_IP:5000/api/health`. For a real public deployment, configure HTTPS and a reverse proxy (for example Nginx) rather than leaving the API exposed without TLS.

### D. Deploy the frontend to S3
1. Set `frontend/.env`:
```
VITE_API_BASE_URL=https://YOUR_API_DOMAIN
```
Use your API's HTTPS URL. Avoid putting database credentials in frontend variables.
2. Build the frontend:
```bash
cd frontend
npm install
npm run build
```
3. Create an S3 bucket and upload the **contents** of `frontend/dist`.
4. Configure website delivery using CloudFront (recommended for HTTPS). Configure the distribution's origin as the S3 bucket, and use the default root object `index.html`.
5. Keep the bucket private when using CloudFront Origin Access Control. Do not make the bucket public unless you understand the implications.

### E. CORS
Set `FRONTEND_ORIGIN` in backend `.env` to the exact deployed frontend origin, such as `https://d123example.cloudfront.net`, then restart the backend.

## 4. API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API health |
| GET | `/api/notes?search=term` | List/search notes |
| POST | `/api/notes` | Create note |
| PUT | `/api/notes/:id` | Edit note |
| PATCH | `/api/notes/:id/pin` | Pin/unpin |
| DELETE | `/api/notes/:id` | Delete note |

## Important security notes
- Never commit `.env`, passwords, access keys, or private keys.
- Use a private RDS database and allow DB access only from EC2.
- Use HTTPS for the deployed frontend and API.
- Use a strong unique database password.
- This starter project does not include user accounts or per-user note isolation. It is intended as a single-user/student demonstration. Do not put private or sensitive notes into a public demo.
- Check AWS Billing regularly and delete resources when finished. Deleting an EC2 instance does not automatically delete EBS volumes, snapshots, Elastic IPs, RDS databases, or S3 data.
