import React, { useEffect, useMemo, useState } from 'react';
import {
  Search,
  Plus,
  Pin,
  Pencil,
  Trash2,
  X,
  BookOpen,
  StickyNote,
  Check,
  LoaderCircle,
  Moon,
  Sun
} from 'lucide-react';

const API = (
  import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'
).replace(/\/$/, '');

export default function App() {
  const [notes, setNotes] = useState([]);
  const [search, setSearch] = useState('');
  const [dialog, setDialog] = useState(null);
  const [form, setForm] = useState({ title: '', content: '' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  // Dark mode state
  const [darkMode, setDarkMode] = useState(
    () => localStorage.getItem('notes-theme') === 'dark'
  );

  // Apply and remember theme
  useEffect(() => {
    document.documentElement.setAttribute(
      'data-theme',
      darkMode ? 'dark' : 'light'
    );

    localStorage.setItem(
      'notes-theme',
      darkMode ? 'dark' : 'light'
    );
  }, [darkMode]);

  // API request helper
  async function request(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    });

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(
        data.error || `Request failed (${response.status})`
      );
    }

    return response.status === 204 ? null : response.json();
  }

  // Load notes
  async function loadNotes(term = search) {
    setLoading(true);
    setError('');

    try {
      const data = await request(
        `/api/notes?search=${encodeURIComponent(term)}`
      );

      setNotes(data);
    } catch (e) {
      setError(
        `${e.message}. Check that the backend and MySQL database are running.`
      );
    } finally {
      setLoading(false);
    }
  }

  // Initial loading
  useEffect(() => {
    loadNotes('');
  }, []);

  // Search notes
  useEffect(() => {
    const timer = setTimeout(() => {
      loadNotes(search);
    }, 250);

    return () => clearTimeout(timer);
  }, [search]);

  // Pinned and regular notes
  const pinned = useMemo(
    () => notes.filter(note => note.isPinned),
    [notes]
  );

  const regular = useMemo(
    () => notes.filter(note => !note.isPinned),
    [notes]
  );

  // Open new note dialog
  function openNew() {
    setForm({ title: '', content: '' });
    setDialog({ mode: 'new' });
  }

  // Open edit dialog
  function openEdit(note) {
    setForm({
      title: note.title,
      content: note.content
    });

    setDialog({
      mode: 'edit',
      note
    });
  }

  // Save note
  async function saveNote(event) {
    event.preventDefault();

    if (!form.title.trim() || !form.content.trim()) {
      return;
    }

    setSaving(true);
    setError('');

    try {
      if (dialog.mode === 'new') {
        await request('/api/notes', {
          method: 'POST',
          body: JSON.stringify(form)
        });
      } else {
        await request(`/api/notes/${dialog.note.id}`, {
          method: 'PUT',
          body: JSON.stringify(form)
        });
      }

      setDialog(null);
      await loadNotes();
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  // Pin and unpin
  async function togglePin(note) {
    try {
      await request(`/api/notes/${note.id}/pin`, {
        method: 'PATCH'
      });

      await loadNotes();
    } catch (e) {
      setError(e.message);
    }
  }

  // Delete note
  async function deleteNote(note) {
    if (
      !window.confirm(
        `Delete "${note.title}"? This cannot be undone.`
      )
    ) {
      return;
    }

    try {
      await request(`/api/notes/${note.id}`, {
        method: 'DELETE'
      });

      await loadNotes();
    } catch (e) {
      setError(e.message);
    }
  }

  // Note card
  function NoteCard({ note }) {
    return (
      <article
        className={`note-card ${note.isPinned ? 'pinned' : ''}`}
      >
        <div className="note-top">
          <span className="note-tag">
            {note.isPinned ? (
              <>
                <Pin size={13} /> Pinned
              </>
            ) : (
              'NOTE'
            )}
          </span>

          <button
            className={`icon-btn pin-btn ${
              note.isPinned ? 'active' : ''
            }`}
            title={
              note.isPinned ? 'Unpin note' : 'Pin note'
            }
            onClick={() => togglePin(note)}
          >
            <Pin size={17} />
          </button>
        </div>

        <h3>{note.title}</h3>

        <p className="note-content">
          {note.content}
        </p>

        <div className="note-footer">
          <span>
            {new Date(note.updatedAt).toLocaleDateString(
              undefined,
              {
                month: 'short',
                day: 'numeric',
                year: 'numeric'
              }
            )}
          </span>

          <div className="actions">
            <button
              className="icon-btn"
              title="Edit note"
              onClick={() => openEdit(note)}
            >
              <Pencil size={16} />
            </button>

            <button
              className="icon-btn delete-btn"
              title="Delete note"
              onClick={() => deleteNote(note)}
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>
      </article>
    );
  }

  return (
    <main className="app-shell">

      {/* Sidebar */}
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-icon">
            <StickyNote size={22} />
          </span>

          <span>NoteSpace</span>
        </div>

        <div className="side-label">
          WORKSPACE
        </div>

        <div className="nav-item selected">
          <BookOpen size={18} />
          All notes

          <span className="count">
            {notes.length}
          </span>
        </div>

        <div className="side-tip">
          <div className="tip-icon">
            <Check size={17} />
          </div>

          <strong>Your thoughts, organized.</strong>

          <p>
            Keep your ideas in one simple place.
          </p>
        </div>

        <div className="sidebar-bottom">
          Notes Manager <span>·</span> v1.1
        </div>
      </aside>

      {/* Main content */}
      <section className="main-area">

        {/* Header */}
        <header className="topbar">
          <div>
            <div className="eyebrow">
              YOUR WORKSPACE
            </div>

            <h1>My Notes</h1>

            <p className="subheading">
              Capture ideas. Keep what matters.
            </p>
          </div>

          <div className="topbar-actions">

            {/* Theme toggle */}
            <button
              className="theme-btn"
              onClick={() => setDarkMode(value => !value)}
              title={
                darkMode
                  ? 'Switch to light mode'
                  : 'Switch to dark mode'
              }
              aria-label={
                darkMode
                  ? 'Switch to light mode'
                  : 'Switch to dark mode'
              }
            >
              {darkMode ? (
                <Sun size={19} />
              ) : (
                <Moon size={19} />
              )}
            </button>

            {/* New note */}
            <button
              className="primary-btn"
              onClick={openNew}
            >
              <Plus size={18} />
              New note
            </button>

          </div>
        </header>

        {/* Search toolbar */}
        <div className="toolbar">
          <div className="search-box">
            <Search size={18} />

            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search your notes..."
              aria-label="Search notes"
            />

            {search && (
              <button
                className="clear-search"
                onClick={() => setSearch('')}
                aria-label="Clear search"
              >
                <X size={15} />
              </button>
            )}
          </div>

          <span className="note-count">
            {notes.length}{' '}
            {notes.length === 1 ? 'note' : 'notes'}
          </span>
        </div>

        {/* Error message */}
        {error && (
          <div className="error-banner">
            {error}

            <button onClick={() => setError('')}>
              <X size={16} />
            </button>
          </div>
        )}

        {/* Notes content */}
        {loading ? (
          <div className="loading">
            <LoaderCircle className="spin" size={22} />
            Loading notes...
          </div>
        ) : notes.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">
              <StickyNote size={30} />
            </div>

            <h2>
              {search
                ? 'No matching notes'
                : 'Your space is ready'}
            </h2>

            <p>
              {search
                ? 'Try another search term.'
                : 'Create your first note and get your ideas flowing.'}
            </p>

            {!search && (
              <button
                className="primary-btn"
                onClick={openNew}
              >
                <Plus size={18} />
                Create a note
              </button>
            )}
          </div>
        ) : (
          <div className="notes-content">

            {/* Pinned notes */}
            {pinned.length > 0 && (
              <section className="note-section">
                <div className="section-heading">
                  <Pin size={15} />
                  PINNED

                  <span>{pinned.length}</span>
                </div>

                <div className="notes-grid">
                  {pinned.map(note => (
                    <NoteCard
                      key={note.id}
                      note={note}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Regular notes */}
            {regular.length > 0 && (
              <section className="note-section">
                <div className="section-heading">
                  ALL NOTES

                  <span>{regular.length}</span>
                </div>

                <div className="notes-grid">
                  {regular.map(note => (
                    <NoteCard
                      key={note.id}
                      note={note}
                    />
                  ))}
                </div>
              </section>
            )}

          </div>
        )}

        <footer className="page-footer">
          Made for keeping your ideas close.
        </footer>

      </section>

      {/* Create and edit modal */}
      {dialog && (
        <div
          className="modal-backdrop"
          onMouseDown={e => {
            if (e.target === e.currentTarget) {
              setDialog(null);
            }
          }}
        >
          <form
            className="note-modal"
            onSubmit={saveNote}
          >
            <div className="modal-header">
              <div>
                <div className="eyebrow">
                  {dialog.mode === 'new'
                    ? 'NEW NOTE'
                    : 'EDIT NOTE'}
                </div>

                <h2>
                  {dialog.mode === 'new'
                    ? 'Create a note'
                    : 'Update your note'}
                </h2>
              </div>

              <button
                type="button"
                className="icon-btn"
                onClick={() => setDialog(null)}
                aria-label="Close dialog"
              >
                <X size={20} />
              </button>
            </div>

            <label>
              Title

              <input
                autoFocus
                maxLength={160}
                value={form.title}
                onChange={e =>
                  setForm({
                    ...form,
                    title: e.target.value
                  })
                }
                placeholder="Give your note a title"
                required
              />
            </label>

            <label>
              Content

              <textarea
                rows={7}
                value={form.content}
                onChange={e =>
                  setForm({
                    ...form,
                    content: e.target.value
                  })
                }
                placeholder="Start writing..."
                required
              />
            </label>

            <div className="modal-actions">
              <button
                type="button"
                className="secondary-btn"
                onClick={() => setDialog(null)}
              >
                Cancel
              </button>

              <button
                className="primary-btn"
                disabled={saving}
              >
                {saving
                  ? 'Saving...'
                  : dialog.mode === 'new'
                    ? 'Create note'
                    : 'Save changes'}
              </button>
            </div>
          </form>
        </div>
      )}

    </main>
  );
}
